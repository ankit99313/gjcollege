<?php 
$subject = $_GET['sub'];

if($subject=="Physics"){   
$imagepath="architects-and-worker.jpg";
$title="Department of physics";
$description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Chemistry"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Chemistry";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Maths"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Maths";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Biology"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Biology";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Zoologoy"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Zoologoy";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="History"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of History";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Political"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Political";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Economics"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Economics";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Sociology"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Sociology";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Philosophy"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Philosophy";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Psychology"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Psychology";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="Commerce"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of Commerce";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}
if($subject=="hindi"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of hindi";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="english"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of english";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="BCA"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of bca";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="BBM"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of bbm";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="BSC"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of bsc";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

if($subject=="BLIS"){
    $imagepath="architects-and-worker.jpg";
    $title="Department of blis";
    $description="Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore ipsam in repudiandae iure ducimus aspernatur esse aliquam velit architecto! Sunt aliquam odio impedit numquam autem eligendi quas, qui
quod accusantium enim voluptatum culpa modi perferendis nostrum molestias cupiditate nam rem! Soluta
omnis mollitia dignissimos minima debitis ut quasi eveniet ex, est sunt totam sit quae doloribus aut
odit exercitationem cum magni! Est maxime mollitia atque, cumque voluptatum amet quisquam quo
voluptates debitis temporibus dolorem eum itaque, sed nemo suscipit. Laboriosam, ea necessitatibus.
Eveniet eaque libero velit, quam minima illum molestiae non neque, voluptas quo illo voluptatum
cupiditate quibusdam voluptatem vero";
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../../css/bs-css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/fonts/ionicons.min.css">
  
    <link rel="stylesheet" href="../../css/navbar.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

  
   
     <!-- footer css-->
     <link rel="stylesheet" href="../../css/Footer-Dark.css">
    <link rel="stylesheet" href="../../assets/fonts/ionicons.min.css">

 
   
</head>

<body>
<?php include '../partial/navbar.php';?>
    <div>
        <img src="../../assets/img/<?php echo $imagepath; ?>" alt="Image" class="w-100" style="aspect-ratio: 16/3;">
    </div>

    <h4 class="text-center py-2"> <?php echo $title; ?> </h4>
    <div class="container-fluid">
        <div class="row g-0 " style=" background-color: #CCCCCC;">
            <div class="col-md-3 bg-primary p-5 ">
                <ul class="list-group list-group-flush shadow-lg link-cla">
                    <li class="list-group-item list-group-item-action "><a href="faculty/<?php echo $subject ?>.php" class="text-decoration-none">Faculaty Members</a></li>
                    <li class="list-group-item list-group-item-action"><a href="#" class="text-decoration-none">Course and syllabus</a></li>
                    <li class="list-group-item list-group-item-action"><a href="#" class="text-decoration-none">example</a></li>
                    <li class="list-group-item list-group-item-action"><a href="#" class="text-decoration-none">example</a></li>
                </ul>
            </div>

            <div class="col-md-6 p-2">
                <img src="../../assets/img/<?php echo $imagepath; ?>" alt="" class="float-start m-2" style="width: 125px;aspect-ratio: 1/1;">
                <p style=" word-spacing: 6px;"> <?php echo $description ?> </p>
            </div>
            <div class="col-md-3 bg-primary p-5"></div>
        </div>
    </div>
    <script src="../../js/bs-js/bootstrap.bundle.min.js"></script>
    
    
    <?php include '../partial/footer.php';?>

    <script src="../../js/jquery.min.js"></script>
</body>

</html>