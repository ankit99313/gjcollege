<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About</title>
  <link rel="icon" href="img/paintlogo10.png" type="image/png">
  <link rel="stylesheet" href="../css/about.css">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">


  <link rel="stylesheet" href="../bs-css/bootstrap.min.css">

<link rel="stylesheet" href="../FA-css/all.min.css">

<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../css/navbar.css">






 <!-- footer css-->
 <link rel="stylesheet" href="../css/Footer-Dark.css">
<link rel="stylesheet" href="../assets/fonts/ionicons.min.css">
<script src="https://kit.fontawesome.com/8ea186a044.js" crossorigin="anonymous"></script>

<script src="https://kit.fontawesome.com/8ea186a044.js" crossorigin="anonymous"></script>

  
</head>
<body>
  

<?php $page='about'; include '../partial/navbar.php';?>


  <div class="about-secti">
        <div class="inner-contain">
            <h1>I.A</h1>
            <p class="textpa">
               This is dummy text hisd fhiiiiiiiiii sdfhusf dfhhhhhhhhhhh agufffffffffffffsd uhsddddddd

            </p>
           <div class="skills">
                <span>Web Design</span>
                <span>Android</span>
              
            </div>
        </div>
    </div>


    <script defer src="../js/navbar.js"></script>

    <script src="../js/jquery.min.js"></script>

<?php include '../partial/footer.php';?>

<script src="../bs-js/bootstrap.bundle.js"></script>


</body>
</html>
























