<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/mission.css" />
</head>
<body>
<div class="row g-0 main-div mt-5">
        <div class="col-sm-4 col-md-4">
            <div class="serviceBox">
                <div class="service-icon"></div>
                <div class="service-content">
                    <h3>Our mission</h3>
                    <hr>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisi risus, condimentum et orci quis, gravida maximus mauris. Praesent varius dolor eget ligula gravida mollis. Praesent ac. </p>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-md-4">
            <div class="serviceBox">
                <div class="service-icon"></div>
                <div class="service-content">
                    <h3>Our vision</h3>
                    <hr>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisi risus, condimentum et orci quis, gravida maximus mauris. Praesent varius dolor eget ligula gravida mollis. Praesent ac. </p>
                </div>
            </div>
        </div>

        <div class="col-sm-4 col-md-4">
            <div class="serviceBox">
                <div class="service-icon"></div>
                <div class="service-content">
                    <h3>Our objective</h3>
                    <hr>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisi risus, condimentum et orci quis, gravida maximus mauris. Praesent varius dolor eget ligula gravida mollis. Praesent ac. </p>
                </div>
            </div>
        </div>
       
    </div>
</body>
</html>