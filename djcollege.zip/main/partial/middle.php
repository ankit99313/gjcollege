<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="css/middle.css" />
    
  </head>
  <body>
    
    <section id="services" class="services mt-5">
      <div class="container-md section-title">
          
          <div class="row">
              <div class="col-12 justify-content-center  text-center col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
                  <div class="text-center icon-box">
                      <div class="icon">
                          <h4 class="title">College event<a href="#"></a></h4>
                          <div class=" overflow-auto  notice-board " " >

                           
                             <div id="marquee-div" class="overflow-hidden">
                               <div  class="overflow-auto mh-70 description">
                             <p>Hower over and hold the mouse marquee stop</p>
                             <p>Hower over and hold the mouse marquee stop</p>
                             <p>Hower over and hold the mouse marquee stop</p>
                             <p>Hower over and hold the mouse marquee stop</p>
                             <p>Hower over and hold the mouse marquee stop</p>
                             <p>Hower over and hold the mouse marquee stop</p>
                             <p>Hower over and hold the mouse marquee stop</p>
                             <p>Hower over and hold the mouse marquee stop</p>
                             <p>Hower over and hold the mouse marquee stop</p>
                           </div>
                            </div>
                           </div>
                      </div>
                  </div>
              </div>
              <div class="col-12 justify-content-center  text-center col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
                <div class="text-center icon-box">
                    <div class="icon">
                        <h4 class="title">Useful link<a href="#"></a></h4>
                        <div class=" overflow-auto  notice-board " " >

                         
                           <div id="marquee-div" class="overflow-hidden second-div">
                             <div  class="overflow-auto mh-70 description">
                           <p>Hower over and hold the mouse marquee stop</p>
                           <p>Hower over and hold the mouse marquee stop</p>
                           <p>Hower over and hold the mouse marquee stop</p>
                           <p>Hower over and hold the mouse marquee stop</p>
                           <p>Hower over and hold the mouse marquee stop</p>
                           <p>Hower over and hold the mouse marquee stop</p>
                           <p>Hower over and hold the mouse marquee stop</p>
                           <p>Hower over and hold the mouse marquee stop</p>
                           <p>Hower over and hold the mouse marquee stop</p>
                         </div>
                          </div>
                         </div>
                    </div>
                </div>
            </div>

            <div class="col-12 justify-content-center  text-center col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
              <div class="text-center icon-box">
                  <div class="icon">
                      <h4 class="title">Notice Board<a href="#"></a></h4>
                      <div class=" overflow-auto  notice-board " " >

                       
                         <div id="marquee-div" class="overflow-hidden">
                           <div id="marquee-content" class="overflow-auto mh-70 description">
                         <p>Hower over and hold the mouse marquee stop</p>
                         <p>Hower over and hold the mouse marquee stop</p>
                         <p>Hower over and hold the mouse marquee stop</p>
                         <p>Hower over and hold the mouse marquee stop</p>
                         <p>Hower over and hold the mouse marquee stop</p>
                         <p>Hower over and hold the mouse marquee stop</p>
                         <p>Hower over and hold the mouse marquee stop</p>
                         <p>Hower over and hold the mouse marquee stop</p>
                         <p>Hower over and hold the mouse marquee stop</p>
                       </div>
                        </div>
                       </div>
                  </div>
              </div>
          </div>
           
             
          </div> 
      </div>
  </section>


 

  
  <div class="row g-0 align-items-center about ">
   
    <div class="col-md-5 ">
      <div class="text-center about-img">
        <img  src="https://hypergroups.in/Visa/images/image-01.png" alt="tab-image" >
      </div>
    </div>

    <div class="col-md-7 text-center">
      <h2>our solgan</h2>
      <p class="px-4"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex labore optio commodi, quas veritatis quod in sit dolor sint ipsam a et Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab aut soluta eius perferendis et assumenda, amet doloribus. Eius repellendus placeat in fugit voluptates ab, distinctio omnis quasi, corrupti reiciendis ea labore odit eum natus tenetur deserunt, laborum mollitia? Tempore sequi dolores perspiciatis optio? Vel recusandae labore ea magni cum cumque aut error nobis corporis asperiores Lorem ipsum dolor sit, amet consectetur adipisicing elit. Similique dolores, id ab repellendus debitis alias accusamus odit laborum nisi, non libero modi dignissimos magni cumque vel! Voluptatum tempore, distinctio nobis exercitationem tenetur ullam.</p>
    </div>

  </div>
  </body>
</html>
